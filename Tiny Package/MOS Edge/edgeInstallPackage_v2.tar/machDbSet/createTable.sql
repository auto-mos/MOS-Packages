create tagdata table tag(name varchar(256) primary key, time datetime basetime, value double summarized);
