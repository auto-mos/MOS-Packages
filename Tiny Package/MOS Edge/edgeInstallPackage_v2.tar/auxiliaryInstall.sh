pip3 install docker==4.2.2
pip3 install dominate==2.6.0
pip3 install entrypoints==0.3
pip3 install Flask==1.1.2
pip3 install Flask-Bootstrap==3.3.7.1
pip3 install Flask-Cors==3.0.8
pip3 install Flask-SocketIO==4.3.2
pip3 install itsdangerous==1.1.0
pip3 install MarkupSafe==2.0.1
pip3 install paho-mqtt==1.5.0
pip3 install python-engineio==3.14.2
pip3 install python-socketio==4.6.1
pip3 install requests==2.24.0
pip3 install schedule==0.6.0
pip3 install urllib3==1.25.11
pip3 install websocket-client==0.59.0
pip3 install Werkzeug==1.0.1


