#!/bin/bash

git clone -b 1.2 https://github.com/open62541/open62541.git
cd open62541
mkdir build
cd build
cmake -DBUILD_SHARED_LIBS=ON -DBUILD_STATIC_LIBS=ON -DUA_ENABLE_ENCRYPTION=OPENSSL -DUA_ENABLE_ENCRYPTION_OPENSSL:BOOL=ON ..
make clean
sudo make install

cd /usr/local/lib
mv /opt/install/libopen62541_cloud.tar ./
tar xvf libopen62541_cloud.tar
rm libopen62541.so.1
ln -sf libopen62541.so.1.2.2 libopen62541.so.1
chown root:root libopen62541.so.1.2.2 
