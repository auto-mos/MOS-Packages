#!/bin/bash

git clone -b 1.2 https://github.com/open62541/open62541.git
cd open62541
mkdir build
cd build
cmake -DBUILD_SHARED_LIBS=ON -DBUILD_STATIC_LIBS=ON -DUA_ENABLE_ENCRYPTION=OPENSSL -DUA_ENABLE_ENCRYPTION_OPENSSL:BOOL=ON ..
make clean
sudo make install

