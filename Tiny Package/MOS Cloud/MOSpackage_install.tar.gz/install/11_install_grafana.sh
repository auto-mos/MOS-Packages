sudo apt-get install -y adduser libfontconfig1
wget https://dl.grafana.com/enterprise/release/grafana-enterprise_8.3.2_amd64.deb
sudo dpkg -i grafana-enterprise_8.3.2_amd64.deb
