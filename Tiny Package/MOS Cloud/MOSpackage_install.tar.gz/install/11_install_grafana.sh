#!/bin/bash
sudo apt-get install -y adduser libfontconfig1
wget https://dl.grafana.com/enterprise/release/grafana-enterprise_8.3.2_amd64.deb
sudo dpkg -i grafana-enterprise_8.3.2_amd64.deb

echo -e "\033[1;32m 11_install_grafana.sh script has finished running."
echo -e "\033[0m"
