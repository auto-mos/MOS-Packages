#!/bin/sh

snap install --classic certbot
