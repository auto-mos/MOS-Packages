#!/bin/bash

cp /opt/install/service/* /lib/systemd/system
systemctl daemon-reload
systemctl enable django
systemctl enable gather
systemctl enable glances
systemctl enable itsdb
systemctl enable restapi

#django.service  gather.service  glances.service  itsdb.service  regi.service
echo -e "\033[1;32m 14_install_systemctl_service.sh script has finished running."
echo -e "\033[0m"
