#!/bin/bash

cp /opt/install/service/* /lib/systemd/system
systemctl daemon-reload

echo -e "\033[1;32m 14_install_systemctl_service.sh script has finished running."
echo -e "\033[0m"
