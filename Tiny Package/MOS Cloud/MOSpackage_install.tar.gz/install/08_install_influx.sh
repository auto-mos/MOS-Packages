#!/bin/bash

# Ubuntu/Debian
wget https://dl.influxdata.com/influxdb/releases/influxdb2-2.6.1-amd64.deb
sudo dpkg -i influxdb2-2.6.1-amd64.deb

wget https://dl.influxdata.com/influxdb/releases/influxdb2-client-2.6.1-linux-amd64.tar.gz
tar xvzf influxdb2-client-2.6.1-linux-amd64.tar.gz
sudo cp influxdb2-client-2.6.1-linux-amd64/influx /usr/bin/

sudo service influxd start

echo -e "\033[1;32m 08_install_influx.sh script has finished running."
echo -e "\033[0m"
