#!/bin/bash

git clone https://github.com/DaveGamble/cJSON.git
cd cJSON
mkdir build
cd build
cmake ..
make clean
make install

echo -e "\033[1;32m 05_install_cjson.sh script has finished running."
echo -e "\033[0m"
