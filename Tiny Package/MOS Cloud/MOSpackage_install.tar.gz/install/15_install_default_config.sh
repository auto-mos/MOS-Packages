#!/bin/sh

cd configs
sudo cp 50-server.cnf /etc/mysql/mariadb.conf.d/
sudo cp nginx.conf /etc/nginx/
sudo cp default /etc/nginx/sites-available/
sudo cp grafana.ini /etc/grafana/
sudo cp settings.py /opt/apps/django/SmartFactory/config/

cd /opt/install
gzip -d libopen62541_cloud.tar.gz
cd /usr/local/lib
mv /opt/install/libopen62541_cloud.tar ./
tar xvf libopen62541_cloud.tar
rm libopen62541.so.1
ln -sf libopen62541.so.1.2.2 libopen62541.so.1
chown root:root libopen62541.so.1.2.2
