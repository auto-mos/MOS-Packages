#!/bin/sh

cd configs
sudo cp 50-server.cnf /etc/mysql/mariadb.conf.d/
sudo cp nginx.conf /etc/nginx/
sudo cp default /etc/nginx/sites-available/
sudo cp grafana.ini /etc/grafana/
sudo cp settings.py /opt/apps/django/SmartFactory/config/

