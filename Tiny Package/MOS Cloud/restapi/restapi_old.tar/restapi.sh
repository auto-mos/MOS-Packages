#!/bin/bash

cd /opt/bin
python restapi.py
