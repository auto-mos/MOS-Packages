#!/bin/bash

/opt/bin/gather_mqtt -c stop 1> /dev/null 2> /dev/null
sleep 1
/bin/rm -f /var/run/gather_mqtt.pid
/opt/bin/gather_mqtt 1> /dev/null 2> /dev/null
