Compass.add_project_configuration('../../../classic/theme-gray/sass/config.rb')
