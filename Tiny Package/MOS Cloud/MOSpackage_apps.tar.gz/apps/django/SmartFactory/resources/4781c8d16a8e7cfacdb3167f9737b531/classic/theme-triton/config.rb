Compass.add_project_configuration('../../../classic/theme-triton/sass/config.rb')
