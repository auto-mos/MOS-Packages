Compass.add_project_configuration('../../../classic/theme-crisp-touch/sass/config.rb')
