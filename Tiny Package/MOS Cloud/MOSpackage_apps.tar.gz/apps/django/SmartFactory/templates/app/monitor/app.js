Ext.application({
    name: 'aasx',
    appFolder: '/resources/app/monitor',
    mainView: 'aasx.view.viewport.aasx',
    controllers: [
        'FrameController'
    ]
});