Ext.application({
    name: 'app',
    appFolder: '/resources/app/main',
    mainView: 'app.view.Viewport',
    controllers: [
        'FrameController'
    ],
    launch: function() {
    }
});