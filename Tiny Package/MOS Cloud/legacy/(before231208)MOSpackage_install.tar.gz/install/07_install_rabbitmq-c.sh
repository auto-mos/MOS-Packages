#!/bin/bash

git clone https://github.com/alanxz/rabbitmq-c.git
cd rabbitmq-c
mkdir build
cd build
cmake ..
make clean
make install

echo -e "\033[1;32m 07_install_rabbitmq-c.sh script has finished running."
echo -e "\033[0m"
