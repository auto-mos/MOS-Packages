sudo apt install --reinstall python3-minimal
sudo apt-key adv --recv-keys --keyserver hkp://keyserver.ubuntu.com:80 0xF1656F24C74CD1D8
sudo add-apt-repository 'deb [arch=amd64,arm64,ppc64el,s390x] http://archive.mariadb.org/mariadb-10.5.9/repo/ubuntu/ focal main main/debug'
sudo apt update
sudo apt-get install mariadb-server -y

echo -e "\033[1;32m 10_install_mariadb.sh script has finished running."
echo -e "\033[0m"
